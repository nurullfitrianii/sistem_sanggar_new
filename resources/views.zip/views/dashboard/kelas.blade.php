<div id="kelas" class="scroll-mt-20 py-10 bg-white">
    <div class="text-center mb-16 px-6">
        <span class="text-[#A47251] font-bold uppercase tracking-wider text-sm">Program Kami</span>
        <h2 class="text-4xl font-bold text-gray-900 mt-2 mb-4">Kelas yang Tersedia</h2>
        <div class="w-16 h-1 bg-[#A47251] mx-auto mb-4"></div>
        <p class="text-gray-600">Pilih kelas yang sesuai dengan minat dan kemampuan Anda.</p>
    </div>

    @php
    $dataKelas = [
        [
            'nama' => 'Seni Tari Tradisional',
            'anggota' => '65 Anggota',
            'desc' => 'Pelajari berbagai tarian tradisional Jawa Barat mulai dari tari jaipong, tari klasik, hingga tari kreasi yang mempertahankan nilai budaya.',
            'kategori' => ['Tari Klasik', 'Tari Kreasi', 'Tari Anak'],
            'jadwal' => [
                ['waktu' => 'Sabtu 14.00 - 16.00 WIB', 'level' => 'Pemula'],
                ['waktu' => 'Sabtu 16.00 - 18.00 WIB', 'level' => 'Menengah & Lanjut']
            ],
            'instruktur' => 'Aulia Rizki W.',
            'durasi' => '2 jam per sesi',
            'harga' => '150.000',
            'sesi' => '4 sesi per bulan',
            'img' => asset('img/seni tari.jpg')
        ],
        [
            'nama' => 'Seni Karawitan - Gamelan',
            'anggota' => '42 Anggota',
            'desc' => 'Kelas komprehensif memainkan instrumen gamelan dan degung Sunda. Mempelajari notasi da-mi-na-ti-la dan harmoni tabuhan bersama.',
            'kategori' => ['Gamelan', 'Degung', 'Grup'],
            'jadwal' => [
                ['waktu' => 'Minggu 09.00 - 11.00 WIB', 'level' => 'Semua Tingkatan']
            ],
            'instruktur' => 'Tim Pelatih',
            'durasi' => '2 jam per sesi',
            'harga' => '150.000',
            'sesi' => '4 sesi per bulan',
            'img' => asset('img/gamelan.jpg')
        ],
        [
            'nama' => 'Seni Karawitan - Kendang',
            'anggota' => '28 Anggota',
            'desc' => 'Fokus pada teknik pukulan dasar hingga lanjutan kendang Sunda (Tepak Tilu, Tepak Dua) untuk mengiringi tarian maupun pencak silat.',
            'kategori' => ['Kendang', 'Perkusi', 'Privat/Grup'],
            'jadwal' => [
                ['waktu' => 'Jumat 15.00 - 17.00 WIB', 'level' => 'Reguler']
            ],
            'instruktur' => 'Pelatih Kendang',
            'durasi' => '2 jam per sesi',
            'harga' => '150.000',
            'sesi' => '4 sesi per bulan',
            'img' => asset('img/kendang.jpg')
        ],
        [
            'nama' => 'Seni Karawitan - Vokal Kawih',
            'anggota' => '35 Anggota',
            'desc' => 'Pelatihan teknik vokal tradisional Sunda (sinden/wiraoswara). Mempelajari cengkok, pedotan, dan penjiwaan lagu-lagu Sunda.',
            'kategori' => ['Vokal', 'Kawih', 'Tembang'],
            'jadwal' => [
                ['waktu' => 'Senin 16.00 - 18.00 WIB', 'level' => 'Pemula'],
                ['waktu' => 'Rabu 16.00 - 18.00 WIB', 'level' => 'Lanjutan']
            ],
            'instruktur' => 'Pelatih Vokal',
            'durasi' => '2 jam per sesi',
            'harga' => '150.000',
            'sesi' => '8 sesi per bulan',
            'img' => asset('img/vokal kawih.jpg')
        ],
        [
            'nama' => 'Seni Karawitan - Kacapi',
            'anggota' => '20 Anggota',
            'desc' => 'Mempelajari teknik petikan Kacapi Indung dan Kacapi Rincik. Cocok untuk mengiringi tembang Sunda Cianjuran atau pop Sunda.',
            'kategori' => ['Kacapi', 'Pemetik', 'Klasik'],
            'jadwal' => [
                ['waktu' => 'Kamis 15.30 - 17.30 WIB', 'level' => 'Semua Tingkatan']
            ],
            'instruktur' => 'Pelatih Kacapi',
            'durasi' => '2 jam per sesi',
            'harga' => '150.000',
            'sesi' => '4 sesi per bulan',
            // Gambar sementara dari internet, silakan ganti kalau udah punya file kacapi.jpg
           'img' => asset('img/kecapi.png')
        ],
        [
            'nama' => 'Seni Karawitan - Suling',
            'anggota' => '15 Anggota',
            'desc' => 'Menguasai teknik tiupan dan penjarian suling bambu Sunda dengan berbagai laras (Pelog, Salendro, Madenda).',
            'kategori' => ['Suling', 'Tiup', 'Reguler'],
            'jadwal' => [
                ['waktu' => 'Selasa 16.00 - 18.00 WIB', 'level' => 'Semua Tingkatan']
            ],
            'instruktur' => 'Pelatih Suling',
            'durasi' => '2 jam per sesi',
            'harga' => '150.000',
            'sesi' => '4 sesi per bulan',
            'img' => asset('img/suling.jpg')
        ]
    ];
    @endphp

    <div class="px-6 md:px-10 max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-8">

        @foreach($dataKelas as $item)
        <div class="bg-white rounded-2xl border border-gray-200 shadow-sm hover:shadow-xl transition-shadow duration-300 overflow-hidden flex flex-col">

            <div class="h-56 overflow-hidden relative">
                <img src="{{ $item['img'] }}" alt="{{ $item['nama'] }}" class="w-full h-full object-cover">
            </div>

            <div class="p-6 md:p-8 flex flex-col flex-grow">

                <div class="flex justify-between items-start mb-3">
                    <h3 class="text-2xl font-bold text-gray-900">{{ $item['nama'] }}</h3>
                    <span class="bg-orange-100 text-[#A47251] text-xs px-2.5 py-1 rounded-md font-semibold whitespace-nowrap">
                        👥 {{ $item['anggota'] }}
                    </span>
                </div>

                <p class="text-gray-600 text-sm leading-relaxed mb-5 flex-grow">
                    {{ $item['desc'] }}
                </p>

                <div class="mb-5">
                    <p class="text-xs text-gray-500 mb-2">Kategori Kelas:</p>
                    <div class="flex flex-wrap gap-2">
                        @foreach($item['kategori'] as $kat)
                        <span class="border border-gray-200 text-gray-600 text-xs px-3 py-1 rounded-full">{{ $kat }}</span>
                        @endforeach
                    </div>
                </div>

                <div class="mb-5 space-y-2">
                    <p class="text-xs text-gray-500 mb-1">Jadwal Latihan:</p>
                    @foreach($item['jadwal'] as $jdwl)
                    <div class="border border-gray-200 rounded-lg p-3 flex justify-between items-center bg-gray-50/30">
                        <div class="flex items-center gap-2 text-sm text-gray-700">
                            <span class="text-orange-600">📅</span> {{ $jdwl['waktu'] }}
                        </div>
                        <span class="bg-blue-50 text-blue-600 text-xs px-3 py-1 rounded-md font-medium">{{ $jdwl['level'] }}</span>
                    </div>
                    @endforeach
                </div>

                <div class="grid grid-cols-2 gap-4 mb-6">
                    <div class="flex items-center gap-2">
                        <span class="text-gray-400 text-lg">👨‍🏫</span>
                        <div>
                            <p class="text-[10px] text-gray-400 uppercase tracking-wider">Instruktur</p>
                            <p class="text-sm font-medium text-gray-800">{{ $item['instruktur'] }}</p>
                        </div>
                    </div>
                    <div class="flex items-center gap-2">
                        <span class="text-gray-400 text-lg">⏱️</span>
                        <div>
                            <p class="text-[10px] text-gray-400 uppercase tracking-wider">Durasi</p>
                            <p class="text-sm font-medium text-gray-800">{{ $item['durasi'] }}</p>
                        </div>
                    </div>
                </div>

                <div class="mt-auto pt-4 border-t border-gray-100">
                    <div class="bg-yellow-50/60 border border-yellow-200 rounded-xl p-4 flex justify-between items-end mb-4">
                        <div>
                            <span class="text-orange-800/70 text-xs font-semibold block mb-1">Biaya Iuran</span>
                            <span class="text-[#A47251] font-extrabold text-xl">Rp {{ $item['harga'] }}<span class="text-sm font-medium text-gray-500">/bulan</span></span>
                        </div>
                        <span class="text-[#A47251] text-xs font-semibold">{{ $item['sesi'] }}</span>
                    </div>

                    <a href="#pendaftaran" class="block text-center bg-[#A47251] text-white font-bold py-3.5 px-8 rounded-lg hover:bg-[#8e6245] transition-colors shadow-md w-full">
                        Daftar Kelas Ini
                    </a>
                </div>

            </div>
        </div>
        @endforeach

    </div>
</div>
