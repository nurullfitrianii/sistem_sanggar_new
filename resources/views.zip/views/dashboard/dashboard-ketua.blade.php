@extends('layouts.admin')

@section('title', 'Dashboard Ketua')

@section('content')
<div class="row border-bottom border-light pb-3 mb-4">
    <div class="col-12">
        <h3 class="fw-bold text-dark mb-1">Dashboard Ketua</h3>
        <p class="text-muted mb-0">Pantau seluruh data Sanggar Goong Prasasti secara real-time.</p>
    </div>
</div>

<div class="row g-4 mb-5">
    <div class="col">
        <a href="{{ route('siswa-admin.index') }}" class="text-decoration-none h-100">
            <div class="card card-outline p-3 h-100 hover-lift d-flex flex-column justify-content-center" style="border-left: 4px solid #3B82F6 !important;">
                <h6 class="text-muted small fw-bold uppercase mb-2">Siswa Aktif</h6>
                <h2 class="fw-extrabold text-dark mb-0">{{ $totalSiswaAktif }}</h2>
            </div>
        </a>
    </div>
    <div class="col">
        <a href="{{ route('program-admin.index') }}" class="text-decoration-none h-100">
            <div class="card card-outline p-3 h-100 hover-lift d-flex flex-column justify-content-center" style="border-left: 4px solid #8B5CF6 !important;">
                <h6 class="text-muted small fw-bold uppercase mb-2">Program Kelas</h6>
                <h2 class="fw-extrabold text-dark mb-0">{{ $totalProgram }}</h2>
            </div>
        </a>
    </div>
    <div class="col">
        <a href="{{ route('siswa-admin.index') }}" class="text-decoration-none h-100">
            <div class="card card-outline p-3 h-100 hover-lift d-flex flex-column justify-content-center" style="border-left: 4px solid #14B8A6 !important;">
                <h6 class="text-muted small fw-bold uppercase mb-2">Pelatih</h6>
                <h2 class="fw-extrabold text-dark mb-0">{{ $totalPelatih }}</h2>
            </div>
        </a>
    </div>
    <div class="col">
        <a href="{{ route('laporan.keuangan') }}" class="text-decoration-none h-100">
            <div class="card card-outline p-3 h-100 hover-lift d-flex flex-column justify-content-center" style="border-left: 4px solid #10B981 !important;">
                <h6 class="text-muted small fw-bold uppercase mb-2">Pemasukan</h6>
                <h5 class="fw-bold text-dark mb-0">Rp {{ number_format($totalPemasukan, 0, ',', '.') }}</h5>
            </div>
        </a>
    </div>
    <div class="col">
        <a href="{{ route('siswa-admin.index') }}" class="text-decoration-none h-100">
            <div class="card card-outline p-3 h-100 hover-lift d-flex flex-column justify-content-center" style="border-left: 4px solid #F59E0B !important;">
                <h6 class="text-muted small fw-bold uppercase mb-2">Prestasi</h6>
                <h2 class="fw-extrabold text-dark mb-0">{{ $totalPrestasi }}</h2>
            </div>
        </a>
    </div>
</div>

<div class="row mb-5">
    <div class="col-12">
        <div class="card card-outline p-0 overflow-hidden">
            <div class="card-header bg-white border-bottom border-light pt-4 px-4 pb-3 flex-column d-flex align-items-start">
                <h6 class="fw-bold mb-0 text-dark">Prestasi Terbaru</h6>
                <p class="text-muted small mb-0 mt-1">Daftar penghargaan sanggar</p>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th class="ps-4">Event</th>
                                <th>Tahun</th>
                                <th>Tingkat</th>
                                <th class="pe-4">Sanggar</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($prestasiTerbaru as $prestasi)
                            <tr>
                                <td class="ps-4 fw-bold text-dark">{{ $prestasi->nama_event }}</td>
                                <td>{{ $prestasi->tahun }}</td>
                                <td><span class="badge bg-soft-warning text-warning px-3 rounded-pill">{{ $prestasi->tingkat }}</span></td>
                                <td class="pe-4 text-muted">{{ $prestasi->sanggar->nama_sanggar ?? '-' }}</td>
                            </tr>
                            @empty
                            <tr><td colspan="4" class="text-center py-5 text-muted">Belum ada data prestasi.</td></tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row mb-5">
    <div class="col-12">
        <div class="card card-outline px-4 py-4 mb-4">
            <div class="d-flex align-items-start gap-4">
                <div class="bg-soft-primary rounded-circle d-flex p-3 justify-content-center align-items-center" style="width: 60px; height: 60px; background-color: #FEF3C7;">
                    <i class="bi bi-calendar3 fs-3" style="color: #92400E;"></i>
                </div>
                <div>
                    <h6 class="fw-bold text-dark mb-2">Manajemen Jadwal Latihan</h6>
                    <p class="text-muted small mb-3">Pantau dan kelola jadwal latihan rutin sanggar untuk memastikan aktivitas pelatih dan siswa berjalan secara efisien dan terstruktur.</p>
                    <a href="{{ route('jadwal.index') }}" class="btn fw-bold px-4 py-2" style="background-color: var(--sanggar-primary); color: white; border-radius: 8px;">Kelola Seluruh Jadwal</a>
                </div>
            </div>
        </div>
        
        <div class="card card-outline p-4">
            <div class="d-flex justify-content-between align-items-center mb-2">
                <h6 class="fw-bold text-dark mb-0">Statistik Pendaftaran</h6>
                <span class="small fw-bold text-primary">70%</span>
            </div>
            <p class="text-muted small mb-3">Target pendaftaran tahun ini hampir tercapai.</p>
            <div class="progress" style="height: 8px; border-radius: 4px;">
                <div class="progress-bar bg-primary" style="width: 70%;"></div>
            </div>
        </div>
    </div>
</div>

<style>
    .hover-lift { transition: transform 0.3s, box-shadow 0.3s; }
    .hover-lift:hover { transform: translateY(-5px); box-shadow: 0 10px 25px rgba(0,0,0,0.1); }
    .btn-sanggar-light { background: #FFFFFF; color: var(--sanggar-dark); border: none; transition: 0.3s; }
    .btn-sanggar-light:hover { background: var(--sanggar-secondary); color: white; transform: translateY(-3px); }
</style>

<style>
    .bg-sanggar-primary { background-color: var(--sanggar-primary) !important; }
    .bg-soft-warning { background-color: rgba(255, 193, 7, 0.1); color: #ffc107; }
</style>
@endsection
