@extends('layouts.admin')

@section('title', 'Manajemen Jadwal Kelas')

@push('styles')
    <link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.15/index.global.min.css" rel="stylesheet" />
    <style>
        #calendar {
            background: #fff;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }
        .fc-event {
            cursor: pointer;
            border-radius: 6px;
            padding: 3px 5px;
            border: none;
            transition: transform 0.2s;
        }
        .fc-event:hover {
            transform: scale(1.02);
            z-index: 10;
        }
        /* Custom Colors for Sanggar Theme */
        .fc-theme-standard th { 
            background-color: #503422; /* Maroon/Brown dark */
            color: white; 
            border-color: #503422; 
            padding: 10px 0; 
            text-transform: uppercase;
            font-size: 14px;
        }
        .fc-theme-standard td { border-color: #f0e9e4; }
        .fc-day-sat, .fc-day-sun { 
            background-color: rgba(255, 152, 0, 0.1) !important; 
            border-top: 4px solid #ff9800 !important; 
        }
        .fc-timegrid-slot-label { color: #503422; font-weight: bold; }
        .fc .fc-button-primary {
            background-color: #A47251 !important;
            border-color: #A47251 !important;
        }
        .fc .fc-button-primary:hover {
            background-color: #8e6245 !important;
            border-color: #8e6245 !important;
        }
    </style>
@endpush

@section('content')
<div class="d-flex justify-content-between align-items-center mb-3" data-aos="fade-down">
    <h1 class="h4 mb-0 fw-bold">Jadwal Kelas (Master List)</h1>
</div>

@if(session('success'))
    <div class="alert alert-success">{{ session('success') }}</div>
@endif

<div class="row g-4 mb-4" data-aos="fade-up">
    <div class="col-md-3">
        <label class="form-label fw-bold">Filter Jenis Kelas</label>
        <select id="filterKelas" class="form-select border-primary shadow-sm">
            <option value="all">Semua Kelas</option>
            @foreach($kelas as $k)
                <option value="{{ $k->id_program }}">{{ $k->nama_program }}</option>
            @endforeach
        </select>
    </div>
</div>

<div class="row g-4" data-aos="fade-up" data-aos-delay="100">
    <div class="col-12">
        <div id="calendar"></div>
    </div>
</div>

<!-- Modal Detail -->
<div class="modal fade" id="eventModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-0 shadow-lg" style="border-radius: 15px;">
      <div class="modal-header border-0 pb-0">
        <h5 class="modal-title fw-bold" id="eventTitle">Detail Jadwal</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <p class="mb-1"><i class="bi bi-person-badge text-primary me-2"></i> <strong>Pelatih:</strong> <span id="eventPelatih"></span></p>
        <p class="mb-1"><i class="bi bi-geo-alt text-danger me-2"></i> <strong>Lokasi:</strong> <span id="eventLokasi"></span></p>
        <p class="mb-1"><i class="bi bi-clock text-warning me-2"></i> <strong>Waktu:</strong> <span id="eventWaktu"></span></p>
      </div>
    </div>
  </div>
</div>

<div class="row mt-5" data-aos="fade-up">
    <div class="col-12">
        <h4 class="fw-bold mb-4 border-bottom pb-2"><i class="bi bi-people-fill text-primary"></i> Daftar Siswa per Program</h4>
        <div class="row g-4">
            @foreach($kelas as $k)
            <div class="col-md-6">
                <div class="card border-0 shadow-sm rounded-4 h-100">
                    <div class="card-header bg-primary text-white border-0 py-3" style="border-radius: 1rem 1rem 0 0; background: linear-gradient(135deg, #A47251, #8e6245) !important;">
                        <h5 class="mb-1 fw-bold">{{ $k->nama_program }}</h5>
                        @php
                            $isSeniTari = strpos(strtolower($k->nama_program), 'tari') !== false;
                            $waktuStr = "Sabtu & Minggu | " . ($isSeniTari ? "10:00 - 13:00" : "13:00 - 17:00") . " WIB";
                        @endphp
                        <span class="badge bg-white text-dark shadow-sm px-3 py-2 mt-1 rounded-pill" style="font-size: 0.85rem;">
                            <i class="bi bi-clock-history text-warning me-1"></i> Jadwal: {{ $waktuStr }}
                        </span>
                    </div>
                    <div class="card-body p-0">
                        <ul class="list-group list-group-flush">
                            @forelse($k->pendaftaran as $pend)
                                <li class="list-group-item px-4 py-3 d-flex justify-content-between align-items-center">
                                    <div>
                                        <span class="fw-semibold">{{ $pend->nama_calon }}</span>
                                        <br>
                                        <small class="text-muted">{{ $pend->username }}</small>
                                    </div>
                                    <span class="badge bg-{{ $pend->status == 'Disetujui' ? 'success' : 'warning' }} rounded-pill">
                                        {{ $pend->status }}
                                    </span>
                                </li>
                            @empty
                                <li class="list-group-item text-center text-muted py-4">Belum ada siswa terdaftar</li>
                            @endforelse
                        </ul>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</div>

@endsection

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.15/index.global.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    var calendarEl = document.getElementById('calendar');
    var filterSelect = document.getElementById('filterKelas');
    
    @php
        $events = [];
        
        foreach($kelas as $i => $k) {
            $isSeniTari = strpos(strtolower($k->nama_program), 'tari') !== false;
            
            $events[] = [
                'id' => 'v_'.$k->id_program,
                'title' => $k->nama_program,
                'startTime' => $isSeniTari ? '10:00:00' : '13:00:00',
                'endTime' => $isSeniTari ? '13:00:00' : '17:00:00',
                'daysOfWeek' => [0, 6], // Minggu(0) dan Sabtu(6)
                'startRecur' => date('Y-m-d'),
                'endRecur' => '2026-12-31',
                'backgroundColor' => $isSeniTari ? '#A47251' : '#DD9E59',
                'borderColor' => $isSeniTari ? '#8e6245' : '#c7863d',
                'extendedProps' => [
                    'pelatih' => 'Virtual System',
                    'lokasi' => 'Sanggar Utama',
                    'id_program' => $k->id_program,
                    'edit_url' => '#' // Virtual, no edit
                ]
            ];
        }
    @endphp
    
    var allEvents = @json($events);

    var calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'timeGridWeek',
        headerToolbar: {
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,timeGridWeek,timeGridDay'
        },
        slotMinTime: '08:00:00',
        slotMaxTime: '22:00:00',
        events: allEvents,
        allDaySlot: false,
        height: 'auto',
        eventClick: function(info) {
            document.getElementById('eventTitle').innerText = info.event.title;
            document.getElementById('eventPelatih').innerText = info.event.extendedProps.pelatih;
            document.getElementById('eventLokasi').innerText = info.event.extendedProps.lokasi;
            
            // Format waktu
            var start = info.event.start;
            var end = info.event.end;
            var formatTime = (date) => date.toLocaleTimeString('id-ID', {hour: '2-digit', minute:'2-digit'});
            document.getElementById('eventWaktu').innerText = formatTime(start) + ' - ' + (end ? formatTime(end) : 'Selesai');
            
            var modal = new bootstrap.Modal(document.getElementById('eventModal'));
            modal.show();
        }
    });
    
    calendar.render();

    // Filter Logic
    filterSelect.addEventListener('change', function() {
        var selectedId = this.value;
        calendar.removeAllEvents();
        
        var filteredEvents = allEvents.filter(function(event) {
            return selectedId === 'all' || event.extendedProps.id_program == selectedId;
        });
        
        calendar.addEventSource(filteredEvents);
    });
});
</script>
@endpush
