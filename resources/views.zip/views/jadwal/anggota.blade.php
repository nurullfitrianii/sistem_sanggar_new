@extends('layouts.admin')

@section('title', 'Jadwal Saya')

@section('content')
<div class="row border-bottom border-light pb-3 mb-4">
    <div class="col-12">
        <h3 class="fw-bold text-dark mb-1">Jadwal Kelas Saya</h3>
        <p class="text-muted mb-0">Program: {{ $defaultTab }}</p>
    </div>
</div>

<div class="row">
    <div class="col-12">
        <div class="card card-outline px-4 py-4 shadow-sm" style="border-radius: 20px;">
            <x-calendar-grid :schedules="$jadwal" :pelatih="$pelatih" :defaultTab="$defaultTab" />
        </div>
    </div>
</div>
@endsection
