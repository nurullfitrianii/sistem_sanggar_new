<div class="event-card">
    <div class="event-title">
        {{ $jadwal->programKelas->nama_program ?? 'Program Tidak Ditemukan' }}
    </div>
    
    <div class="event-meta">
        <i class="bi bi-clock"></i> 
        {{ \Carbon\Carbon::parse($jadwal->jam_mulai)->format('H:i') }} - {{ \Carbon\Carbon::parse($jadwal->jam_selesai)->format('H:i') }}
    </div>
    
    <div class="event-meta">
        <i class="bi bi-person-badge"></i> 
        {{ $jadwal->pelatih->nama_pelatih ?? '-' }}
    </div>
    
    <div class="event-meta">
        <i class="bi bi-geo-alt"></i> 
        {{ $jadwal->lokasi ?? 'Studio Sanggar' }}
    </div>

    @if($role === 'ketua')
        <div class="event-actions">
            <a href="{{ route('jadwal.edit', $jadwal->id_jadwal) }}" class="btn btn-sm btn-outline-primary py-0 px-2" style="font-size: 0.7rem;">
                <i class="bi bi-pencil"></i> Edit
            </a>
            <form action="{{ route('jadwal.destroy', $jadwal->id_jadwal) }}" method="POST" class="m-0 p-0" onsubmit="return confirm('Hapus jadwal ini?');">
                @csrf
                @method('DELETE')
                <button type="submit" class="btn btn-sm btn-outline-danger py-0 px-2" style="font-size: 0.7rem;">
                    <i class="bi bi-trash"></i> Hapus
                </button>
            </form>
        </div>
    @endif
</div>
