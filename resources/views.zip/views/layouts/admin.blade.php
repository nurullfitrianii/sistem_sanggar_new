<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <title>@yield('title', 'Dashboard Sanggar')</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Fonts & Icons -->
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

    <style>
        :root {
            --sanggar-primary: #A47251;
            --sanggar-secondary: #DD9E59;
            --sanggar-dark: #2D241E;
            --sanggar-light: #FFFFFF;
            --sidebar-width: 280px;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: #FAFAFA;
            color: #433422;
            overflow-x: hidden;
        }

        /* Sidebar Styles */
        /* Sidebar Styles */
        #sidebar {
            width: var(--sidebar-width);
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            background: #FFFFFF;
            color: var(--sanggar-dark);
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            z-index: 1000;
            border-right: 1px solid rgba(164, 114, 81, 0.1);
            overflow-y: auto;
        }

        .sidebar-header {
            padding: 2.5rem 1.5rem;
            background: transparent;
            border-bottom: 1px solid rgba(164, 114, 81, 0.1);
            margin-bottom: 1rem;
        }

        .nav-sidebar {
            padding: 0.5rem 1rem;
        }

        .nav-sidebar .nav-item {
            margin-bottom: 0.5rem;
        }

        .nav-sidebar .nav-link {
            color: #4B5563; /* Slate 600 equivalent */
            padding: 0.85rem 1.25rem;
            border-radius: 12px;
            display: flex;
            align-items: center;
            gap: 14px;
            transition: all 0.3s;
            font-weight: 600;
            border: 1px solid transparent;
        }

        .nav-sidebar .nav-link:hover {
            color: var(--sanggar-primary);
            background: rgba(164, 114, 81, 0.05);
            transform: translateX(4px);
        }

        .nav-sidebar .nav-link.active {
            color: var(--sanggar-primary);
            background: #FFF7ED; /* Very soft orange/yellow */
            font-weight: 700;
            border: none;
        }

        .nav-sidebar .nav-link i {
            font-size: 1.4rem;
            color: #9CA3AF; /* Gray icon initially */
            transition: all 0.3s;
        }

        .nav-sidebar .nav-link.active i {
            color: var(--sanggar-primary);
        }

        .nav-sidebar .nav-link:hover i {
            color: var(--sanggar-secondary);
            transform: scale(1.1);
        }

        /* Main Content Styles */
        #content {
            margin-left: var(--sidebar-width);
            min-height: 100vh;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .top-navbar {
            background: rgba(255, 255, 255, 0.8);
            backdrop-filter: blur(10px);
            padding: 1.25rem 2.5rem;
            box-shadow: 0 4px 20px rgba(0,0,0,0.03);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 999;
            border-bottom: 1px solid rgba(164, 114, 81, 0.05);
        }

        .user-profile {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 5px 15px;
            border-radius: 12px;
            transition: all 0.3s;
        }

        .user-profile:hover {
            background: rgba(164, 114, 81, 0.05);
        }

        .user-avatar {
            width: 44px;
            height: 44px;
            background: linear-gradient(135deg, var(--sanggar-primary), var(--sanggar-secondary));
            color: white;
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            box-shadow: 0 5px 15px rgba(164, 114, 81, 0.3);
            border: 2px solid white;
        }

        /* Responsive */
        @media (max-width: 992px) {
            #sidebar { margin-left: calc(-1 * var(--sidebar-width)); }
            #content { margin-left: 0; }
            #sidebar.active { margin-left: 0; }
        }

        .btn-sanggar {
            background: var(--sanggar-primary);
            color: white;
            border: none;
            padding: 0.75rem 1.75rem;
            border-radius: 14px;
            font-weight: 600;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 0 4px 12px rgba(164, 114, 81, 0.15);
        }

        .btn-sanggar:hover {
            background: #8e6245;
            color: white;
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(164, 114, 81, 0.25);
        }

        .section-card {
            background: white;
            border-radius: 1.25rem;
            border: 1px solid rgba(164, 114, 81, 0.06);
            box-shadow: 0 8px 24px rgba(45, 36, 30, 0.04);
            margin-bottom: 1.5rem;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .card-outline {
            background: #FFFFFF;
            border-radius: 1.25rem;
            border: 1px solid #E5E7EB;
            box-shadow: 0 2px 10px rgba(0,0,0,0.01);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .section-card:hover {
            box-shadow: 0 15px 45px rgba(45, 36, 30, 0.08);
            transform: translateY(-2px);
        }

        /* Modern Form Overrides */
        .form-control, .form-select {
            border-radius: 12px;
            padding: 0.75rem 1.25rem;
            border: 1px solid rgba(164, 114, 81, 0.15);
            transition: all 0.3s;
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--sanggar-secondary);
            box-shadow: 0 0 0 4px rgba(221, 158, 89, 0.1);
            background-color: #fff;
        }

        .card {
            border-radius: 1.25rem;
            border: none;
            box-shadow: 0 4px 16px rgba(0,0,0,0.03);
        }

        /* Global Table Hover & Transitions */
        .table tr {
            transition: all 0.3s ease;
        }
        .table-hover tbody tr:hover {
            background-color: rgba(164, 114, 81, 0.05) !important;
            transform: scale(1.002);
            box-shadow: 0 4px 15px rgba(0,0,0,0.02);
        }

        .dropdown-menu {
            animation: slideUp 0.3s ease;
            border: none;
            box-shadow: 0 15px 40px rgba(0,0,0,0.1);
        }

        @keyframes slideUp {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Enforce Brand Colors on Bootstrap Utilities & Global Elements */
        .text-primary { color: var(--sanggar-primary) !important; }
        .bg-primary { background-color: var(--sanggar-primary) !important; }
        .border-primary { border-color: var(--sanggar-primary) !important; }

        .btn-primary {
            background-color: var(--sanggar-primary) !important;
            border-color: var(--sanggar-primary) !important;
            border-radius: 12px;
            padding: 0.6rem 1.75rem;
            font-weight: 600;
            box-shadow: 0 4px 12px rgba(164, 114, 81, 0.2);
        }
        .btn-primary:hover {
            background-color: var(--sanggar-secondary) !important;
            border-color: var(--sanggar-secondary) !important;
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(221, 158, 89, 0.3);
        }

        .btn-outline-primary {
            color: var(--sanggar-primary) !important;
            border-color: var(--sanggar-primary) !important;
        }
        .btn-outline-primary:hover {
            background-color: var(--sanggar-primary) !important;
            color: white !important;
        }

        .dropdown-item.active, .dropdown-item:active {
            background-color: var(--sanggar-primary);
        }

        .pagination .page-item.active .page-link {
            background-color: var(--sanggar-primary);
            border-color: var(--sanggar-primary);
        }
        .pagination .page-link {
            color: var(--sanggar-primary);
        }

        /* Interactive Card Lift */
        .hover-lift {
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .hover-lift:hover {
            transform: translateY(-8px);
            box-shadow: 0 15px 35px rgba(164, 114, 81, 0.15) !important;
        }
    </style>
    @stack('styles')
</head>
<body>

    <!-- Sidebar -->
    <nav id="sidebar">
        <div class="sidebar-header">
            <div class="d-flex align-items-center gap-3">
                <div class="bg-white p-2 rounded-3 d-flex align-items-center justify-content-center">
                    <img src="{{ asset('img/Logo.png') }}" height="38" alt="Logo">
                </div>
                <div>
                    <h6 class="mb-0 fw-bold text-dark">Sanggar Goong</h6>
                    <small style="color: var(--sanggar-secondary); font-weight: 500; font-size: 0.75rem;">Prasasti</small>
                </div>
            </div>
        </div>

        <ul class="nav flex-column nav-sidebar">
            @php $role = strtolower(auth()->user()->role ?? ''); @endphp

            @if($role === 'ketua')
                <li class="nav-item">
                    <a href="{{ route('dashboard.ketua') }}" class="nav-link {{ request()->routeIs('dashboard.ketua') ? 'active' : '' }}">
                        <i class="bi bi-grid-1x2"></i> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a href="{{ route('siswa-admin.index') }}" class="nav-link {{ request()->routeIs('siswa-admin.*') ? 'active' : '' }}">
                        <i class="bi bi-people"></i> Kelola Siswa
                    </a>
                </li>
                <li class="nav-item">
                    <a href="{{ route('pengguna.index') }}" class="nav-link {{ request()->routeIs('pengguna.*') ? 'active' : '' }}">
                        <i class="bi bi-person-badge"></i> Kelola Pengguna
                    </a>
                </li>
                <li class="nav-item">
                    <a href="{{ route('jadwal.index') }}" class="nav-link {{ request()->routeIs('jadwal.*') ? 'active' : '' }}">
                        <i class="bi bi-calendar3"></i> Jadwal Kelas
                    </a>
                </li>
                <li class="nav-item">
                    <a href="{{ route('absensi.index') }}" class="nav-link {{ request()->routeIs('absensi.*') ? 'active' : '' }}">
                        <i class="bi bi-check2-square"></i> Laporan Kehadiran
                    </a>
                </li>

                <li class="nav-item">
                    <a href="{{ route('laporan.keuangan') }}" class="nav-link {{ request()->routeIs('laporan.keuangan') ? 'active' : '' }}">
                        <i class="bi bi-file-earmark-bar-graph"></i> Laporan Keuangan
                    </a>
                </li>

            @elseif($role === 'humas')
                <li class="nav-item">
                    <a href="{{ route('dashboard.humas') }}" class="nav-link {{ request()->routeIs('dashboard.humas') ? 'active' : '' }}">
                        <i class="bi bi-grid-1x2"></i> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a href="{{ route('pendaftaran.index') }}" class="nav-link {{ request()->routeIs('pendaftaran.*') ? 'active' : '' }}">
                        <i class="bi bi-person-plus"></i> Pendaftaran
                    </a>
                </li>
                <li class="nav-item">
                    <a href="{{ route('humas.absensi.index') }}" class="nav-link {{ request()->routeIs('humas.absensi.*') ? 'active' : '' }}">
                        <i class="bi bi-calendar2-check"></i> Kehadiran
                    </a>
                </li>
                <li class="nav-item bg-white-20 my-2 mx-3" style="height: 1px; background: rgba(255,255,255,0.1);"></li>
                <li class="nav-item">
                    <a href="{{ route('program-admin.index') }}" class="nav-link {{ request()->routeIs('program-admin.*') ? 'active' : '' }}">
                        <i class="bi bi-star"></i> Kelola Program
                    </a>
                </li>
                <li class="nav-item">
                    <a href="{{ route('berita-admin.index') }}" class="nav-link {{ request()->routeIs('berita-admin.*') ? 'active' : '' }}">
                        <i class="bi bi-newspaper"></i> Kelola Berita
                    </a>
                </li>
                <li class="nav-item">
                    <a href="{{ route('galeri-admin.index') }}" class="nav-link {{ request()->routeIs('galeri-admin.*') ? 'active' : '' }}">
                        <i class="bi bi-images"></i> Kelola Galeri
                    </a>
                </li>

            @elseif($role === 'bendahara')
    <li class="nav-item">
        <a href="{{ route('dashboard.bendahara') }}" class="nav-link {{ request()->routeIs('dashboard.bendahara') ? 'active' : '' }}">
            <i class="bi bi-grid-1x2"></i> Dashboard
        </a>
    </li>
    <li class="nav-item">
        <a href="{{ route('siswa-admin.index') }}" class="nav-link {{ request()->routeIs('siswa-admin.*') ? 'active' : '' }}">
            <i class="bi bi-people"></i> Kelola Siswa
        </a>
    </li>

    {{-- MENU VERIFIKASI YANG BARU (HALAMAN KHUSUS) --}}
    <li class="nav-item">
        <a href="{{ route('bendahara.verifikasi_index') }}" class="nav-link {{ request()->routeIs('bendahara.verifikasi_index') ? 'active' : '' }} d-flex align-items-center justify-content-between">
            <div class="d-flex align-items-center gap-3">
                <i class="bi bi-patch-check"></i>
                <span>Verifikasi Pembayaran</span>
            </div>
            {{-- Badge Notifikasi tetep dipasang di sini biar keren --}}
            @if(isset($totalPending) && $totalPending > 0)
                <span class="badge rounded-pill bg-danger" style="font-size: 0.65rem; padding: 0.4em 0.6em;">
                    {{ $totalPending }}
                </span>
            @endif
        </a>
    </li>

    <li class="nav-item">
        <a href="{{ route('bendahara.iuran.index') }}" class="nav-link {{ request()->routeIs('bendahara.iuran.index') ? 'active' : '' }}">
            <i class="bi bi-wallet2"></i> Data Iuran
        </a>
    </li>

    <li class="nav-item">
        <a href="{{ route('keuangan-bendahara.index') }}" class="nav-link {{ request()->routeIs('keuangan-bendahara.*') ? 'active' : '' }}">
            <i class="bi bi-cash-stack"></i> Transaksi Keuangan
        </a>
    </li>

    <li class="nav-item">
        <a href="{{ route('laporan.keuangan.bendahara') }}" class="nav-link {{ request()->routeIs('laporan.keuangan.bendahara') ? 'active' : '' }}">
            <i class="bi bi-file-earmark-text"></i> Laporan Keuangan
        </a>
    </li>

            @elseif($role === 'siswa')
                <li class="nav-item">
                    <a href="{{ route('dashboard.siswa') }}" class="nav-link {{ request()->routeIs('dashboard.siswa') ? 'active' : '' }}">
                        <i class="bi bi-grid-1x2"></i> Beranda
                    </a>
                </li>
                <li class="nav-item">
                    <a href="{{ route('jadwal.anggota') }}" class="nav-link">
                        <i class="bi bi-calendar3"></i> Jadwal Kelas
                    </a>
                </li>
                <li class="nav-item">
                    <a href="{{ route('absensi.anggota') }}" class="nav-link">
                        <i class="bi bi-check2-square"></i> Absensi
                    </a>
                </li>
            @endif
        </ul>
    </nav>

    <!-- Content -->
    <main id="content">
        <header class="top-navbar">
            <div class="d-flex align-items-center">
                <button class="btn border-0 d-lg-none" id="sidebarCollapse">
                    <i class="bi bi-list fs-3"></i>
                </button>
            </div>

            <div class="dropdown">
                <div class="user-profile dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                    <div class="text-end d-none d-sm-block">
                        <h6 class="mb-0 fw-bold">{{ auth()->user()->username }}</h6>
                        <small class="text-muted">{{ auth()->user()->role }}</small>
                    </div>
                    <div class="user-avatar text-white">
                        {{ strtoupper(substr(auth()->user()->username, 0, 1)) }}
                    </div>
                </div>
                <ul class="dropdown-menu dropdown-menu-end border-0 shadow-lg p-2 rounded-3 mt-3">
                    <li><a class="dropdown-item py-2 px-3 rounded-2" href="{{ route('profile.index') }}"><i class="bi bi-person me-2"></i> Profil</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li>
                        <form method="POST" action="{{ route('logout') }}">
                            @csrf
                            <button class="dropdown-item py-2 px-3 rounded-2 text-danger"><i class="bi bi-box-arrow-right me-2"></i> Keluar</button>
                        </form>
                    </li>
                </ul>
            </div>
        </header>

        <div class="container-fluid py-4 px-4">
            @yield('content')
        </div>
    </main>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

    @if(session('success'))
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            Swal.fire({
                icon: 'success',
                title: 'Berhasil!',
                text: '{!! session("success") !!}',
                confirmButtonColor: '#A47251',
                confirmButtonText: 'Tutup'
            });
        });
    </script>
    @endif

    @if(session('error_403'))
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            Swal.fire({
                icon: 'error',
                title: 'Akses Ditolak!',
                text: '{!! session("error_403") !!}',
                confirmButtonColor: '#A47251',
                confirmButtonText: 'Kembali'
            });
        });
    </script>
    @endif

    @if(session('error'))
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: '{!! session("error") !!}',
                confirmButtonColor: '#A47251',
                confirmButtonText: 'Tutup'
            });
        });
    </script>
    @endif

    @if($errors->any())
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            Swal.fire({
                icon: 'warning',
                title: 'Perhatian',
                text: 'Terdapat beberapa isian yang tidak valid, mohon periksa kembali formulir Anda.',
                confirmButtonColor: '#DD9E59',
                confirmButtonText: 'Oke'
            });
        });
    </script>
    @endif
    <script>
        document.getElementById('sidebarCollapse')?.addEventListener('click', function() {
            document.getElementById('sidebar').classList.toggle('active');
        });

        AOS.init({
            duration: 800,
            once: true
        });

        // Global Modal residual cleaner (Fixes "Overlay redup" bug on browser back/forward)
        window.addEventListener('pageshow', function (event) {
            const backdrops = document.querySelectorAll('.modal-backdrop');
            backdrops.forEach(backdrop => backdrop.remove());
            document.body.classList.remove('modal-open');
            document.body.style.overflow = '';
            document.body.style.paddingRight = '';
        });
    </script>
    @stack('scripts')
</body>
</html>
