<?php

namespace App\Http\Controllers;

use App\Models\JadwalLatihan;
use App\Models\Pelatih;
use App\Models\ProgramKelas;
use App\Models\Sanggar;
use Illuminate\Http\Request;
use SimpleSoftwareIO\QrCode\Facades\QrCode;

class JadwalController extends Controller
{
    public function index()
    {
        $jadwal = JadwalLatihan::with(['pelatih', 'programKelas', 'sanggar'])
            ->orderBy('hari')
            ->get();
        $pelatih = Pelatih::all();
        $kelas = ProgramKelas::with(['pendaftaran' => function($query) {
            $query->where('status', 'Disetujui')->orWhere('status', 'Menunggu');
        }, 'jadwalLatihan'])->where('status', 'Aktif')->get();
        return view('jadwal.index', compact('jadwal', 'pelatih', 'kelas'));
    }

    public function create()
    {
        $pelatih = Pelatih::all();
        $kelas = ProgramKelas::all();
        $sanggar = Sanggar::all();

        return view('jadwal.create', compact('pelatih', 'kelas', 'sanggar'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'id_pelatih'  => ['required', 'exists:pelatih,id_pelatih'],
            'id_program'  => ['required', 'exists:program_kelas,id_program'],
            'id_sanggar'  => ['required', 'exists:sanggar,id_sanggar'],
            'hari'        => ['required', 'string'],
            'jam_mulai'   => ['required'],
            'jam_selesai' => ['required'],
            'lokasi'      => ['nullable', 'string', 'max:100'],
        ]);

        JadwalLatihan::create($data);
        return redirect()->route('jadwal.index')->with('success', 'Data jadwal berhasil disimpan.');
    }

    public function edit($id)
    {
        $jadwal = JadwalLatihan::findOrFail($id);
        $pelatih = Pelatih::all();
        $kelas = ProgramKelas::all(); // Disamakan dengan fungsi create
        $sanggar = Sanggar::all();

        return view('jadwal.edit', compact('jadwal', 'pelatih', 'kelas', 'sanggar'));
    }
    public function update(Request $request, $id)
    {
        $jadwal = JadwalLatihan::findOrFail($id);
        $data = $request->validate([
            'id_pelatih'  => ['nullable', 'exists:pelatih,id_pelatih'],
            'id_program'  => ['nullable', 'exists:program_kelas,id_program'],
            'id_sanggar'  => ['nullable', 'exists:sanggar,id_sanggar'],
            'hari'        => ['required', 'string'],
            'jam_mulai'   => ['required'],
            'jam_selesai' => ['required'],
            'lokasi'      => ['nullable', 'string', 'max:100'],
        ]);

        $jadwal->update($data);

        return redirect()->route('jadwal.index')->with('success', 'Data jadwal berhasil diperbarui.');
    }

    public function destroy($id)
    {
        $jadwal = JadwalLatihan::findOrFail($id);
        $jadwal->delete();

        return redirect()->route('jadwal.index')->with('success', 'Data jadwal berhasil dihapus.');
    }

   public function jadwalAnggota()
{
    $user = auth()->user();
    $pendaftaran = \App\Models\Pendaftaran::with('programKelas')->where('username', $user->username)->first();

    if (!$pendaftaran) {
        return redirect()->back()->with('error', 'Silahkan daftar program terlebih dahulu.');
    }

    // Ambil semua jadwal untuk kalender bulanan
    $jadwal = JadwalLatihan::with(['pelatih', 'programKelas'])
        ->where('id_program', $pendaftaran->id_program)
        ->get();

    // Ambil daftar semua pelatih untuk bagian Participant di kanan
    $pelatih = \App\Models\Pelatih::all();

    $defaultTab = $pendaftaran->programKelas->nama_program;

    return view('jadwal.anggota', compact('jadwal', 'defaultTab', 'pelatih'));
}
}

