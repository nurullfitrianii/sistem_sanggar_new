<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\ProgramKelas;
use App\Models\LaporanKeuangan;
use App\Models\Prestasi;
use App\Models\Pelatih;
use App\Models\Sanggar;
use App\Models\Transaction;

class KetuaController extends Controller
{
    public function index()
    {
        return view('dashboard.dashboard-ketua', [
            'totalSiswaAktif'    => User::where('role', 'Siswa')->where('status', 'Aktif')->count(),
            'totalProgram'       => ProgramKelas::count(),
            'totalPemasukan'     => Transaction::where('jenis', 'Masuk')->sum('nominal'),
            'totalPrestasi'      => Prestasi::count(),
            'totalPelatih'       => Pelatih::count(),
            'totalSanggar'       => Sanggar::count(),
            'prestasiTerbaru'    => Prestasi::with('sanggar')->orderByDesc('tahun')->take(5)->get(),
        ]);
    }
}
