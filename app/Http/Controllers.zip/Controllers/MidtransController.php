<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Pendaftaran;
use Illuminate\Support\Facades\Log;

class MidtransController extends Controller
{
    public function callback(Request $request)
    {
        $serverKey = env('MIDTRANS_SERVER_KEY');
        $hashed = hash("sha512", $request->order_id . $request->status_code . $request->gross_amount . $serverKey);

        // Validasi agar data yang masuk beneran dari Midtrans, bukan orang iseng
        if ($hashed == $request->signature_key) {

            // Ambil ID Pendaftaran dari Order ID (Tadi kita buat format: REG-ID-TIME)
            $orderParts = explode('-', $request->order_id);
            $id_pendaftaran = $orderParts[1];

            $pendaftaran = Pendaftaran::find($id_pendaftaran);

            if ($pendaftaran) {
                if ($request->transaction_status == 'capture' || $request->transaction_status == 'settlement') {
                    $pendaftaran->update(['status_pembayaran' => 'success']);
                } elseif ($request->transaction_status == 'pending') {
                    $pendaftaran->update(['status_pembayaran' => 'pending']);
                } elseif ($request->transaction_status == 'deny' || $request->transaction_status == 'expire' || $request->transaction_status == 'cancel') {
                    $pendaftaran->update(['status_pembayaran' => 'failed']);
                }
            }
        }

        return response()->json(['status' => 'ok']);
    }
}
