<?php

namespace App\Http\Controllers;

use App\Models\ProgramKelas;
use App\Models\Galeri;
use App\Models\InformasiBerita;

class HumasController extends Controller
{
    public function index()
    {
        return view('dashboard.humas', [
            'totalProgram'  => ProgramKelas::count(),
            'totalGaleri'   => Galeri::count(),
            'totalBerita'   => InformasiBerita::count(),
            'beritaTerbaru' => InformasiBerita::orderByDesc('tanggal_publish')->take(5)->get(),
        ]);
    }
}
