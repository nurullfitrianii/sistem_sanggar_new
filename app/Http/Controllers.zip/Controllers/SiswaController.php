<?php

namespace App\Http\Controllers;

use App\Models\JadwalLatihan;
use App\Models\Absensi;
use App\Models\Pembayaran;
use App\Models\Pendaftaran;
use App\Models\Pelatih;
use App\Models\Transaction;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SiswaController extends Controller
{
    private function checkAndGenerateMonthlyBill($user)
    {
        $pendaftaran = Pendaftaran::where('username', $user->username)->first();
        if (!$pendaftaran || !$pendaftaran->tanggal_daftar) return;

        $startDate = Carbon::parse($pendaftaran->tanggal_daftar);
        $now = Carbon::now();

        $current = $startDate->copy()->startOfMonth();
        while ($current->lte($now->copy()->startOfMonth())) {
            $monthName = $current->translatedFormat('F Y');

            $exists = Pembayaran::where('id_user', $user->id_user)
                ->where('bulan', $monthName)
                ->exists();

            if (!$exists) {
                $biaya = $pendaftaran->programKelas ? $pendaftaran->programKelas->biaya : 0;
                Pembayaran::create([
                    'id_user' => $user->id_user,
                    'bulan'   => $monthName,
                    'jumlah'  => $biaya,
                    'status'  => 'Belum Bayar',
                ]);
            }
            $current->addMonth();
        }
    }

    public function index()
    {
        $user = auth()->user();
        $pendaftaran = Pendaftaran::with('programKelas')->where('username', $user->username)->first();

        if ($user->status === 'Menunggu') {
            return view('dashboard.anggota', [
                'pendaftaran'  => $pendaftaran,
                'statusTracking' => true
            ]);
        }

        $this->checkAndGenerateMonthlyBill($user);

        return view('dashboard.anggota', [
            'pendaftaran'       => $pendaftaran,
            'pelatih'           => Pelatih::all(),
            'defaultTab'        => ($pendaftaran && $pendaftaran->programKelas) ? $pendaftaran->programKelas->nama_program : 'Umum',
            'jadwalSaya'        => JadwalLatihan::with(['programKelas', 'pelatih', 'sanggar'])
                                    ->where('id_program', $pendaftaran ? $pendaftaran->id_program : null)
                                    ->whereIn('hari', ['Sabtu', 'Minggu'])
                                    ->orderBy('hari')
                                    ->get(),
            'riwayatAbsensi'    => Absensi::with('jadwalLatihan.programKelas')
                                    ->where('id_user', $user->id_user)
                                    ->orderByDesc('waktu_hadir')
                                    ->limit(10)
                                    ->get(),
            'riwayatPembayaran' => Pembayaran::where('id_user', $user->id_user)
                                    ->orderByDesc('id_pembayaran')
                                    ->get(),
        ]);
    }

    /**
     * FIX: Tunai → Menunggu Verifikasi (bendahara yang validasi, baru masuk transactions)
     *      Transfer → Menunggu Verifikasi, Midtrans callback yang set Lunas + insert transactions
     */
    public function bayarIuran(Request $request, $id)
    {
        $pembayaran = Pembayaran::findOrFail($id);
        $user = auth()->user();

        // Jika Tunai → tunggu verifikasi bendahara
        if ($request->metode_pembayaran === 'tunai') {
            $pembayaran->update([
                'tipe_iuran'        => $request->tipe_iuran,
                'metode_pembayaran' => $request->metode_pembayaran,
                'jumlah'            => $request->jumlah_bayar,
                'status'            => 'Menunggu Verifikasi',
            ]);

            return response()->json([
                'status'  => 'success',
                'metode'  => 'tunai',
                'message' => 'Berhasil! Silakan setor tunai ke pengurus.'
            ]);
        }

        // Jika Transfer via Midtrans → set pending dulu, callback yang selesaikan
        $pembayaran->update([
            'tipe_iuran'        => $request->tipe_iuran,
            'metode_pembayaran' => $request->metode_pembayaran,
            'jumlah'            => $request->jumlah_bayar,
            'status'            => 'Menunggu Verifikasi',
        ]);

        \Midtrans\Config::$serverKey = config('midtrans.server_key');
        \Midtrans\Config::$isProduction = false;
        \Midtrans\Config::$isSanitized = true;
        \Midtrans\Config::$is3ds = true;

        $params = [
            'transaction_details' => [
                'order_id'     => 'IUR-' . $pembayaran->id_pembayaran . '-' . uniqid(),
                'gross_amount' => (int) $request->jumlah_bayar,
            ],
            'customer_details' => [
                'first_name' => $user->username,
                'email'      => $user->email,
            ],
        ];

        $snapToken = \Midtrans\Snap::getSnapToken($params);

        return response()->json([
            'status' => 'success',
            'metode' => 'transfer',
            'token'  => $snapToken
        ]);
    }

    /**
     * FIX: Saat Midtrans settlement → set Lunas + tanggal_bayar + insert ke transactions
     */
    public function callback(Request $request)
    {
        $serverKey = config('midtrans.server_key');
        $hashed = hash("sha512", $request->order_id . $request->status_code . $request->gross_amount . $serverKey);

        if ($hashed == $request->signature_key) {
            if ($request->transaction_status == 'capture' || $request->transaction_status == 'settlement') {
                $orderParts    = explode('-', $request->order_id);
                $id_pembayaran = $orderParts[1] ?? null;

                if (!$id_pembayaran) return;

                $pembayaran = Pembayaran::find($id_pembayaran);
                if ($pembayaran) {
                    $pembayaran->update([
                        'status'        => 'Lunas',
                        'tanggal_bayar' => now(),
                    ]);

                    // Insert ke transactions agar masuk Laporan Keuangan
                    $keterangan = 'Iuran ' . ucfirst($pembayaran->tipe_iuran ?? 'Bulanan') . ': '
                                . ($pembayaran->user->username ?? 'Siswa')
                                . ' (' . $pembayaran->bulan . ')';

                    $trxExists = Transaction::where('nominal', $pembayaran->jumlah)
                        ->where('keterangan', $keterangan)
                        ->exists();

                    if (!$trxExists) {
                        Transaction::create([
                            'tanggal'    => now(),
                            'jenis'      => 'Masuk',
                            'nominal'    => $pembayaran->jumlah,
                            'keterangan' => $keterangan,
                            'id_user'    => $pembayaran->id_user,
                        ]);
                    }
                }
            }
        }
    }

    public function downloadQR()
    {
        $user = auth()->user();
        $qrCode = \SimpleSoftwareIO\QrCode\Facades\QrCode::format('svg')
                     ->size(500)
                     ->margin(2)
                     ->generate($user->id_user);

        return response($qrCode)
                ->header('Content-Type', 'image/svg+xml')
                ->header('Content-Disposition', 'attachment; filename="QR_SGP_' . $user->username . '.svg"');
    }
}
