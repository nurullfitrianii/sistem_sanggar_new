<?php namespace App\Http\Controllers;

use App\Models\Transaction;
use Illuminate\Http\Request;

class KeuanganController extends Controller
{
    protected function routePrefix(): string
    {
        return request()->routeIs('keuangan-bendahara.*') ? 'keuangan-bendahara' : 'keuangan';
    }

    public function index()
    {
        $transaksi = Transaction::with('user')->orderByDesc('tanggal')->paginate(15);
        $routePrefix = $this->routePrefix();
        return view('keuangan.index', compact('transaksi', 'routePrefix'));
    }

    public function create()
    {
        $routePrefix = $this->routePrefix();
        return view('keuangan.create', compact('routePrefix'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'tanggal'     => ['required', 'date'],
            'jenis'       => ['required', 'in:Masuk,Keluar'],
            'nominal'     => ['required', 'numeric', 'min:0'],
            'keterangan'  => ['required', 'string'],
        ]);

        $data['id_user'] = auth()->user()->id_user;

        Transaction::create($data);

        $routePrefix = $this->routePrefix();
        return redirect()->route($routePrefix . '.index')->with('success', 'Transaksi keuangan berhasil disimpan.');
    }

    public function destroy(Request $request)
    {
        $id = $request->route('keuangan') ?? $request->route('keuangan_bendahara');
        $transaksi = Transaction::findOrFail($id);
        $transaksi->delete();

        $routePrefix = $this->routePrefix();
        return redirect()->route($routePrefix . '.index')->with('success', 'Transaksi berhasil dihapus.');
    }
}

